import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

const LocationContext = createContext(null);

export const LocationProvider = ({ children }) => {
  const [location, setLocation] = useState({
    latitude: null,
    longitude: null,
    accuracy: null,
    timestamp: null,
  });
  const [permissionStatus, setPermissionStatus] = useState('prompt');
  const [isTracking, setIsTracking] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [patientId, setPatientId] = useState(null);
  const [patientName, setPatientName] = useState('');
  const [error, setError] = useState(null);
  const watchIdRef = useRef(null);
  const sharingIntervalRef = useRef(null);

  // Restore state from localStorage on mount
  useEffect(() => {
    const savedState = localStorage.getItem('locationState');
    if (savedState) {
      const state = JSON.parse(savedState);
      setIsTracking(state.isTracking || false);
      setIsSharing(state.isSharing || false);
      setPatientId(state.patientId || null);
      setPatientName(state.patientName || '');
      
      // Resume tracking if it was active
      if (state.isTracking && state.patientId) {
        setPatientId(state.patientId);
        startTracking(state.patientId);
      }
      
      // Resume sharing if it was active
      if (state.isSharing && state.patientName) {
        setPatientName(state.patientName);
        startLiveSharing(state.patientName);
      }
    }
  }, []);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('locationState', JSON.stringify({
      isTracking,
      isSharing,
      patientId,
      patientName,
      timestamp: new Date().toISOString()
    }));
  }, [isTracking, isSharing, patientId, patientName]);

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: new Date().toISOString(),
        });
        setPermissionStatus('granted');
        setError(null);
        
        sendLocationToBackend(position.coords.latitude, position.coords.longitude, position.coords.accuracy);
        
        // Automatically start continuous tracking
        startTracking(patientId);
      },
      (err) => {
        setError(getErrorMessage(err));
        setPermissionStatus('denied');
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 5000,
      }
    );
  };

  const startTracking = (id) => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return;
    }

    if (isTracking) return;

    setPatientId(id);

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: new Date().toISOString(),
        });
        setPermissionStatus('granted');
        setError(null);
        setIsTracking(true);
        
        sendLocationToBackend(position.coords.latitude, position.coords.longitude, position.coords.accuracy);
      },
      (err) => {
        setError(getErrorMessage(err));
        setPermissionStatus('denied');
        stopTracking();
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 5000,
      }
    );
  };

  const stopTracking = () => {
    if (watchIdRef.current) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
      setIsTracking(false);
      stopSharing();
    }
  };

  const startLiveSharing = (name) => {
    if (!isTracking) {
      setError('Please start location tracking first');
      return;
    }

    if (isSharing) return;

    setPatientName(name);
    setIsSharing(true);
    
    // Send location updates to contacts every 30 seconds
    sharingIntervalRef.current = setInterval(() => {
      if (location.latitude && location.longitude) {
        sendLiveLocationToContacts(name);
      }
    }, 30000);

    // Send initial location immediately
    if (location.latitude && location.longitude) {
      sendLiveLocationToContacts(name);
    }
  };

  const stopSharing = () => {
    if (sharingIntervalRef.current) {
      clearInterval(sharingIntervalRef.current);
      sharingIntervalRef.current = null;
      setIsSharing(false);
    }
  };

  const sendLocationToBackend = async (latitude, longitude, accuracy) => {
    try {
      const response = await fetch('http://localhost:8000/api/location/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patient_id: patientId,
          latitude: latitude,
          longitude: longitude,
          accuracy: accuracy,
          source: 'BROWSER_GEOLOCATION',
        }),
      });
      
      if (!response.ok) {
        console.error('Failed to send location to backend');
      }
    } catch (err) {
      console.error('Error sending location to backend:', err);
    }
  };

  const sendLiveLocationToContacts = async (name) => {
    try {
      const response = await fetch('http://localhost:8000/api/notifications/send-location', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patient_id: patientId,
          patient_name: name,
          latitude: location.latitude,
          longitude: location.longitude,
          accuracy: location.accuracy,
        }),
      });
      
      if (!response.ok) {
        console.error('Failed to send live location to contacts');
      }
    } catch (err) {
      console.error('Error sending live location to contacts:', err);
    }
  };

  const getErrorMessage = (error) => {
    switch (error.code) {
      case error.PERMISSION_DENIED:
        return 'Location permission denied. Please enable location access in your browser settings.';
      case error.POSITION_UNAVAILABLE:
        return 'Location information is unavailable.';
      case error.TIMEOUT:
        return 'Location request timed out.';
      default:
        return 'An unknown error occurred while retrieving location.';
    }
  };

  // Check permission status on mount
  useEffect(() => {
    if (navigator.permissions) {
      navigator.permissions.query({ name: 'geolocation' }).then((result) => {
        setPermissionStatus(result.state);
      });
    }
  }, []);

  return (
    <LocationContext.Provider
      value={{
        location,
        permissionStatus,
        isTracking,
        isSharing,
        patientId,
        patientName,
        error,
        getCurrentLocation,
        startTracking,
        stopTracking,
        startLiveSharing,
        stopSharing,
        setPatientId,
        setPatientName,
      }}
    >
      {children}
    </LocationContext.Provider>
  );
};

export const useLocation = () => {
  const context = useContext(LocationContext);
  if (!context) {
    throw new Error('useLocation must be used within LocationProvider');
  }
  return context;
};
