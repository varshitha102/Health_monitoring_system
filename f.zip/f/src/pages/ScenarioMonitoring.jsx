import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Activity } from 'lucide-react';
import websocketService from '../services/websocket';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useLocation } from '../contexts/LocationContext.jsx';
import LocationMap from '../components/LocationMap';

const ScenarioMonitoring = () => {
  const [isStreaming, setIsStreaming] = useState(false);
  const [currentScenario, setCurrentScenario] = useState(null);
  const [healthData, setHealthData] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [patientId, setPatientId] = useState('P001');
  const [patientName, setPatientName] = useState('');
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [streamingProgress, setStreamingProgress] = useState(0);
  const [totalSteps] = useState(60);
  const [alerts, setAlerts] = useState([]);

  const wsRef = useRef(null);

  // Location tracking from context
  const {
    location,
    permissionStatus,
    isTracking: locationTracking,
    isSharing: locationSharing,
    error: locationError,
    getCurrentLocation,
    startTracking,
    stopTracking,
    startLiveSharing,
    stopSharing,
    setPatientId: setLocationPatientId,
  } = useLocation();

  // Update patient ID in context when it changes
  useEffect(() => {
    setLocationPatientId(patientId);
  }, [patientId, setLocationPatientId]);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('patientSettings');
    if (savedSettings) {
      const settings = JSON.parse(savedSettings);
      setPatientId(settings.patientId || 'P001');
      setPatientName(settings.patientName || '');
    }
    setSettingsLoaded(true);
  }, []);

  const scenarios = [
    {
      type: 'NORMAL',
      name: 'Normal Patient',
      description: 'All readings within healthy ranges',
      color: 'green',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-500',
      textColor: 'text-green-700'
    },
    {
      type: 'WARNING',
      name: 'Warning Patient',
      description: 'Moderately elevated vital signs',
      color: 'yellow',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-500',
      textColor: 'text-yellow-700'
    },
    {
      type: 'CRITICAL',
      name: 'Critical Patient',
      description: 'Severely abnormal vital signs',
      color: 'red',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-500',
      textColor: 'text-red-700'
    }
  ];

  const startStreaming = (scenarioType) => {
    if (isStreaming) return;

    if (!patientName.trim()) {
      alert('Please enter a patient name before starting monitoring. This name will be used in emergency SMS alerts.');
      return;
    }

    const wsUrl = `ws://localhost:8000/ws/monitor/${patientId}?patient_name=${encodeURIComponent(patientName)}&scenario=${scenarioType}&steps=${totalSteps}&interval=1.0&notifications=true`;
    websocketService.connect(wsUrl);

    websocketService.subscribe((data) => {
      if (data.type === 'alert_sent') {
        setAlerts(prev => [...prev, data]);
      } else {
        // Health reading data
        setHealthData(data);
        setChartData(prev => [...prev, {
          time: new Date(data.timestamp).toLocaleTimeString(),
          temperature: data.temperature,
          heartRate: data.heart_rate,
          spo2: data.spo2
        }].slice(-60)); // Keep last 60 points

        setStreamingProgress(data.step + 1);
        setCurrentScenario(data.scenario_type);

        if (data.step >= totalSteps - 1) {
          stopStreaming();
        }
      }
    });

    setCurrentScenario(scenarioType);
    setIsStreaming(true);
    setStreamingProgress(0);
    setChartData([]);
    setAlerts([]);
  };

  const stopStreaming = () => {
    websocketService.disconnect();
    setIsStreaming(false);
  };

  const resetStream = () => {
    stopStreaming();
    setHealthData(null);
    setChartData([]);
    setStreamingProgress(0);
    setCurrentScenario(null);
    setAlerts([]);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'NORMAL': return 'bg-green-100 text-green-800';
      case 'WARNING': return 'bg-yellow-100 text-yellow-800';
      case 'CRITICAL': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Patient Profile Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-xl flex items-center justify-center text-white text-2xl font-bold shadow-lg">
              {patientName ? patientName.charAt(0).toUpperCase() : '?'}
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-800">{patientName || 'Not Configured'}</h3>
              <p className="text-sm text-slate-500">Patient ID: {patientId}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  locationTracking ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'
                }`}>
                  {locationTracking ? '● Location Active' : '○ Location Inactive'}
                </span>
                {locationSharing && (
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-[#E3EF4F] text-[#1F06AC]">
                    ● Sharing Active
                  </span>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {permissionStatus === 'denied' && (
              <p className="text-sm text-red-600 bg-red-50 px-3 py-1.5 rounded-lg">Location denied</p>
            )}
            {!locationTracking ? (
              <button
                onClick={getCurrentLocation}
                disabled={isStreaming}
                className="bg-[#1F06AC] hover:bg-[#0F42C0] disabled:bg-slate-300 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-md hover:shadow-lg"
              >
                Start Location Session
              </button>
            ) : (
              <button
                onClick={stopTracking}
                className="bg-red-500 hover:bg-red-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-md hover:shadow-lg"
              >
                Stop Location Session
              </button>
            )}
            {!patientName && (
              <Link to="/settings" className="text-sm text-[#1F06AC] hover:text-[#0F42C0] font-semibold flex items-center gap-1">
                Configure Profile →
              </Link>
            )}
          </div>
        </div>
        {locationError && (
          <p className="text-sm text-red-600 mt-3 bg-red-50 p-3 rounded-lg">{locationError}</p>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Scenario Selection */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
            <h2 className="text-xl font-bold text-slate-800 mb-6">Select Health Scenario</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {scenarios.map((scenario) => (
                <button
                  key={scenario.type}
                  onClick={() => startStreaming(scenario.type)}
                  disabled={isStreaming}
                  className={`p-6 rounded-2xl border-2 transition-all duration-200 ${
                    currentScenario === scenario.type
                      ? `${scenario.bgColor} ${scenario.borderColor} ${scenario.textColor} border-2 shadow-lg transform scale-105`
                      : 'bg-white border-slate-200 hover:border-[#5882E8] hover:shadow-md'
                  } ${isStreaming ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <div className="text-4xl mb-3">
                    {scenario.type === 'NORMAL' ? '✅' : scenario.type === 'WARNING' ? '⚠️' : '🚨'}
                  </div>
                  <h3 className="font-bold text-lg">{scenario.name}</h3>
                  <p className="text-sm mt-2 opacity-80">{scenario.description}</p>
                </button>
              ))}
            </div>

            {isStreaming && (
              <div className="mt-6 flex items-center gap-4 p-4 bg-slate-50 rounded-xl">
                <button
                  onClick={stopStreaming}
                  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  Pause
                </button>
                <button
                  onClick={resetStream}
                  className="bg-slate-600 hover:bg-slate-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  Reset
                </button>
                <div className="ml-auto flex items-center gap-2">
                  <div className="w-32 h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-[#1F06AC] transition-all duration-300"
                      style={{ width: `${(streamingProgress / totalSteps) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium text-slate-600">
                    {streamingProgress} / {totalSteps}
                  </span>
                </div>
              </div>
            )}
          </div>

          {healthData && (
            <>
              {/* Health Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className={`bg-white rounded-2xl shadow-sm border-2 p-6 ${
                  healthData.health_status === 'CRITICAL' ? 'border-red-500' :
                  healthData.health_status === 'WARNING' ? 'border-amber-500' : 'border-green-500'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-slate-600">Temperature</h3>
                    <span className={`w-3 h-3 rounded-full ${
                      healthData.health_status === 'CRITICAL' ? 'bg-red-500' :
                      healthData.health_status === 'WARNING' ? 'bg-amber-500' : 'bg-green-500'
                    }`}></span>
                  </div>
                  <p className="text-4xl font-bold text-slate-800">{healthData.temperature}°C</p>
                  <span className={`inline-block mt-3 px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(healthData.health_status)}`}>
                    {healthData.health_status}
                  </span>
                </div>

                <div className={`bg-white rounded-2xl shadow-sm border-2 p-6 ${
                  healthData.health_status === 'CRITICAL' ? 'border-red-500' :
                  healthData.health_status === 'WARNING' ? 'border-amber-500' : 'border-green-500'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-slate-600">Heart Rate</h3>
                    <span className={`w-3 h-3 rounded-full ${
                      healthData.health_status === 'CRITICAL' ? 'bg-red-500' :
                      healthData.health_status === 'WARNING' ? 'bg-amber-500' : 'bg-green-500'
                    }`}></span>
                  </div>
                  <p className="text-4xl font-bold text-slate-800">{healthData.heart_rate} BPM</p>
                  <span className={`inline-block mt-3 px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(healthData.health_status)}`}>
                    {healthData.health_status}
                  </span>
                </div>

                <div className={`bg-white rounded-2xl shadow-sm border-2 p-6 ${
                  healthData.health_status === 'CRITICAL' ? 'border-red-500' :
                  healthData.health_status === 'WARNING' ? 'border-amber-500' : 'border-green-500'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-slate-600">SpO2</h3>
                    <span className={`w-3 h-3 rounded-full ${
                      healthData.health_status === 'CRITICAL' ? 'bg-red-500' :
                      healthData.health_status === 'WARNING' ? 'bg-amber-500' : 'bg-green-500'
                    }`}></span>
                  </div>
                  <p className="text-4xl font-bold text-slate-800">{healthData.spo2}%</p>
                  <span className={`inline-block mt-3 px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(healthData.health_status)}`}>
                    {healthData.health_status}
                  </span>
                </div>
              </div>

              {/* Charts */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Real-Time Health Monitoring</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <h4 className="text-sm font-semibold text-slate-600 mb-3">Temperature (°C)</h4>
                    <div className="h-48">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis dataKey="time" stroke="#64748b" fontSize={12} />
                          <YAxis stroke="#64748b" fontSize={12} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F06AC', color: 'white', borderRadius: '8px' }}
                          />
                          <Line type="monotone" dataKey="temperature" stroke="#ef4444" strokeWidth={2} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-600 mb-3">Heart Rate (BPM)</h4>
                    <div className="h-48">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis dataKey="time" stroke="#64748b" fontSize={12} />
                          <YAxis stroke="#64748b" fontSize={12} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F06AC', color: 'white', borderRadius: '8px' }}
                          />
                          <Line type="monotone" dataKey="heartRate" stroke="#3b82f6" strokeWidth={2} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-600 mb-3">SpO2 (%)</h4>
                    <div className="h-48">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis dataKey="time" stroke="#64748b" fontSize={12} />
                          <YAxis stroke="#64748b" fontSize={12} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#1F06AC', color: 'white', borderRadius: '8px' }}
                          />
                          <Line type="monotone" dataKey="spo2" stroke="#10b981" strokeWidth={2} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>

              {/* Alert History */}
              {alerts.length > 0 && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                  <h3 className="text-xl font-bold text-slate-800 mb-4">Alert History</h3>
                  <div className="space-y-3">
                    {alerts.map((alert, index) => (
                      <div key={index} className={`p-4 rounded-xl border-2 ${
                        alert.alert_level === 'CRITICAL' 
                          ? 'bg-red-50 border-red-200' 
                          : 'bg-amber-50 border-amber-200'
                      }`}>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-bold text-slate-800">{alert.alert_level} Alert Sent</p>
                            <p className="text-sm text-slate-600">{new Date(alert.timestamp).toLocaleString()}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            alert.alert_level === 'CRITICAL' ? 'bg-red-500 text-white' : 'bg-amber-500 text-white'
                          }`}>
                            {alert.alert_level}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Data Source Info */}
              <div className="bg-gradient-to-r from-[#1F06AC]/10 to-[#0F42C0]/10 rounded-xl p-4 border border-[#1F06AC]/20">
                <p className="text-sm text-[#1F06AC]">
                  <strong>Data Source:</strong> SYNTHETIC_SIMULATION | <strong>Patient ID:</strong> {patientId} | <strong>Scenario:</strong> {currentScenario}
                </p>
              </div>
            </>
          )}
        </div>

        {/* Location Map Sidebar */}
        <div className="lg:col-span-1">
          <LocationMap 
            location={location} 
            isTracking={locationTracking}
            isSharing={locationSharing}
            patientId={patientId}
            patientName={patientName}
            onStartSharing={() => startLiveSharing(patientName)}
            onStopSharing={stopSharing}
          />
        </div>
      </div>

      {!healthData && !isStreaming && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center">
          <Activity className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 text-lg">Select a scenario above to begin real-time monitoring</p>
        </div>
      )}
    </div>
  );
};

export default ScenarioMonitoring;
