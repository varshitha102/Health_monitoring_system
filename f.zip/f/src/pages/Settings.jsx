import React, { useState, useEffect } from 'react';
import { Settings as SettingsIcon, User, Mail, Phone, FileText, Save, RotateCcw, CheckCircle, Shield } from 'lucide-react';

const Settings = () => {
  const [settings, setSettings] = useState({
    patientId: 'P001',
    patientName: '',
    age: '',
    email: '',
    phone: '',
    medicalNotes: ''
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const savedSettings = localStorage.getItem('patientSettings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: value
    }));
    setSaved(false);
  };

  const handleSave = () => {
    localStorage.setItem('patientSettings', JSON.stringify(settings));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleReset = () => {
    localStorage.removeItem('patientSettings');
    setSettings({
      patientId: 'P001',
      patientName: '',
      age: '',
      email: '',
      phone: '',
      medicalNotes: ''
    });
    setSaved(false);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-xl flex items-center justify-center">
            <SettingsIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Settings</h2>
            <p className="text-slate-500 text-sm">Manage your patient profile and application preferences</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-lg flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-800">Patient Profile</h3>
              <p className="text-sm text-slate-500">Configure patient information</p>
            </div>
          </div>

          {saved && (
            <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-xl mb-6 flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              Settings saved successfully!
            </div>
          )}

          <form className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Patient ID
                </label>
                <input
                  type="text"
                  name="patientId"
                  value={settings.patientId}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="P001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="patientName"
                  value={settings.patientName}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border-2 border-[#1F06AC] rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="John Smith"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Age
                </label>
                <input
                  type="number"
                  name="age"
                  value={settings.age}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="35"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={settings.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={settings.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="+1234567890"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Medical Notes
              </label>
              <textarea
                name="medicalNotes"
                value={settings.medicalNotes}
                onChange={handleChange}
                rows={3}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all resize-none"
                placeholder="Any relevant medical information..."
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={handleSave}
                className="bg-[#1F06AC] hover:bg-[#0F42C0] text-white px-6 py-2.5 rounded-xl font-semibold transition-all shadow-md hover:shadow-lg flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Settings
              </button>
              <button
                onClick={handleReset}
                className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-6 py-2.5 rounded-xl font-semibold transition-all flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Reset to Default
              </button>
            </div>
          </form>
        </div>

        {/* Info Card */}
        <div className="bg-gradient-to-br from-[#1F06AC]/10 to-[#0F42C0]/10 rounded-2xl p-6 border border-[#1F06AC]/20">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#1F06AC] rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-bold text-[#1F06AC]">Information</h3>
          </div>
          <ul className="space-y-3 text-sm text-slate-700">
            <li className="flex items-start gap-2">
              <span className="text-[#1F06AC] font-bold">•</span>
              <span>Patient Name is used in emergency SMS alerts to family members</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#1F06AC] font-bold">•</span>
              <span>Settings are saved locally in your browser</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#1F06AC] font-bold">•</span>
              <span>These settings will be used automatically in the Scenario Monitoring page</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#1F06AC] font-bold">•</span>
              <span>Age is used for ML predictions on the Patient Prediction page</span>
            </li>
          </ul>

          <div className="mt-6 p-4 bg-white/50 rounded-xl border border-white/30">
            <div className="flex items-center gap-3 mb-2">
              <User className="w-5 h-5 text-[#1F06AC]" />
              <p className="font-semibold text-slate-800">Quick Access</p>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-500" />
                <span className="text-slate-600">{settings.email || 'No email set'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-slate-500" />
                <span className="text-slate-600">{settings.phone || 'No phone set'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
