import React, { useState, useEffect } from 'react';
import { Brain, Activity, Target, Loader2, History, XCircle } from 'lucide-react';
import { predictionsAPI } from '../services/api';

const PatientPrediction = () => {
  const [formData, setFormData] = useState({
    patient_id: '',
    heart_rate_bpm: '',
    spo2_pct: '',
    skin_temp_c: '',
    steps: '',
    age: ''
  });
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [modelInfo, setModelInfo] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    fetchModelInfo();
    fetchHistory();

    const savedSettings = localStorage.getItem('patientSettings');
    if (savedSettings) {
      const settings = JSON.parse(savedSettings);
      setFormData(prev => ({
        ...prev,
        patient_id: settings.patientId || '',
        age: settings.age || ''
      }));
    }
  }, []);

  const fetchModelInfo = async () => {
    try {
      const response = await predictionsAPI.getModelInfo();
      setModelInfo(response.data);
    } catch (err) {
      console.error('Failed to fetch model info:', err);
    }
  };

  const fetchHistory = async () => {
    try {
      const response = await predictionsAPI.getAll({ limit: 10 });
      setHistory(response.data);
    } catch (err) {
      console.error('Failed to fetch history:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setPrediction(null);
    setLoading(true);

    try {
      const response = await predictionsAPI.create({
        patient_id: formData.patient_id,
        heart_rate_bpm: formData.heart_rate_bpm ? parseFloat(formData.heart_rate_bpm) : null,
        spo2_pct: formData.spo2_pct ? parseFloat(formData.spo2_pct) : null,
        skin_temp_c: formData.skin_temp_c ? parseFloat(formData.skin_temp_c) : null,
        steps: formData.steps ? parseInt(formData.steps) : null,
        age: formData.age ? parseInt(formData.age) : null
      });

      setPrediction(response.data);
      fetchHistory();
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to generate prediction');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusConfig = (status) => {
    switch (status) {
      case 'NORMAL':
        return { color: 'green', bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-500' };
      case 'WARNING':
        return { color: 'amber', bg: 'bg-amber-100', text: 'text-amber-800', border: 'border-amber-500' };
      case 'CRITICAL':
        return { color: 'red', bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-500' };
      default:
        return { color: 'slate', bg: 'bg-slate-100', text: 'text-slate-800', border: 'border-slate-500' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-xl flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Patient Health Prediction</h2>
            <p className="text-slate-500 text-sm">AI-powered patient health assessment using trained ML model</p>
          </div>
        </div>
      </div>

      {/* Model Information */}
      {modelInfo && (
        <div className="bg-gradient-to-r from-[#1F06AC]/10 to-[#0F42C0]/10 rounded-2xl p-6 border border-[#1F06AC]/20">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#1F06AC] rounded-lg flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-bold text-[#1F06AC]">Model Information</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white/50 p-4 rounded-xl">
              <p className="text-xs text-slate-500 mb-1">Model Type</p>
              <p className="font-bold text-slate-800">{modelInfo.model_type}</p>
            </div>
            <div className="bg-white/50 p-4 rounded-xl">
              <p className="text-xs text-slate-500 mb-1">Training Samples</p>
              <p className="font-bold text-slate-800">{modelInfo.n_train_samples}</p>
            </div>
            <div className="bg-white/50 p-4 rounded-xl">
              <p className="text-xs text-slate-500 mb-1">Features</p>
              <p className="font-bold text-slate-800">{modelInfo.features?.length}</p>
            </div>
            <div className="bg-white/50 p-4 rounded-xl">
              <p className="text-xs text-slate-500 mb-1">Contamination</p>
              <p className="font-bold text-slate-800">{(modelInfo.contamination_actual * 100).toFixed(1)}%</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-800">Enter Patient Details</h3>
              <p className="text-sm text-slate-500">Input vital signs for prediction</p>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-xl mb-4 flex items-center gap-2">
              <XCircle className="w-4 h-4" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Patient ID *
                </label>
                <input
                  type="text"
                  value={formData.patient_id}
                  onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Age *
                </label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="25-75"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Heart Rate (BPM)
                </label>
                <input
                  type="number"
                  value={formData.heart_rate_bpm}
                  onChange={(e) => setFormData({ ...formData, heart_rate_bpm: e.target.value })}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="60-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  SpO2 (%)
                </label>
                <input
                  type="number"
                  value={formData.spo2_pct}
                  onChange={(e) => setFormData({ ...formData, spo2_pct: e.target.value })}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="95-100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Skin Temperature (°C)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.skin_temp_c}
                  onChange={(e) => setFormData({ ...formData, skin_temp_c: e.target.value })}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="33-35"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Steps
                </label>
                <input
                  type="number"
                  value={formData.steps}
                  onChange={(e) => setFormData({ ...formData, steps: e.target.value })}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#1F06AC] focus:border-transparent transition-all"
                  placeholder="0-2000"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#1F06AC] hover:bg-[#0F42C0] disabled:bg-slate-300 text-white py-3 rounded-xl font-semibold transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Predicting...
                </>
              ) : (
                <>
                  <Target className="w-5 h-5" />
                  Generate Prediction
                </>
              )}
            </button>
          </form>
        </div>

        {/* Prediction Result */}
        {prediction && (
          <div className={`bg-white rounded-2xl shadow-sm border-2 p-6 ${getStatusConfig(prediction.predicted_status).border}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-10 h-10 ${getStatusConfig(prediction.predicted_status).bg} rounded-lg flex items-center justify-center`}>
                <Target className={`w-5 h-5 ${getStatusConfig(prediction.predicted_status).text}`} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-800">Prediction Result</h3>
                <p className="text-sm text-slate-500">AI-based health assessment</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl">
                  <p className="text-xs text-slate-500 mb-1">Patient ID</p>
                  <p className="font-bold text-slate-800">{prediction.patient_id}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl">
                  <p className="text-xs text-slate-500 mb-1">Predicted Status</p>
                  <span className={`px-3 py-1 rounded-full text-sm font-bold ${getStatusConfig(prediction.predicted_status).bg} ${getStatusConfig(prediction.predicted_status).text}`}>
                    {prediction.predicted_status}
                  </span>
                </div>
                {prediction.anomaly_score !== null && (
                  <div className="bg-slate-50 p-4 rounded-xl">
                    <p className="text-xs text-slate-500 mb-1">Anomaly Score</p>
                    <p className="font-bold text-slate-800">{prediction.anomaly_score.toFixed(4)}</p>
                  </div>
                )}
                {prediction.is_anomaly !== null && (
                  <div className="bg-slate-50 p-4 rounded-xl">
                    <p className="text-xs text-slate-500 mb-1">Is Anomaly</p>
                    <p className="font-bold text-slate-800">{prediction.is_anomaly === 1 ? 'Yes' : 'No'}</p>
                  </div>
                )}
              </div>

              <div className="bg-slate-50 p-4 rounded-xl">
                <h4 className="font-semibold text-slate-700 mb-3">Input Summary</h4>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-sm">
                  <div><span className="text-slate-500">HR:</span> <span className="font-semibold">{prediction.heart_rate_bpm || 'N/A'}</span></div>
                  <div><span className="text-slate-500">SpO2:</span> <span className="font-semibold">{prediction.spo2_pct || 'N/A'}</span></div>
                  <div><span className="text-slate-500">Temp:</span> <span className="font-semibold">{prediction.skin_temp_c || 'N/A'}</span></div>
                  <div><span className="text-slate-500">Steps:</span> <span className="font-semibold">{prediction.steps || 'N/A'}</span></div>
                  <div><span className="text-slate-500">Age:</span> <span className="font-semibold">{prediction.age || 'N/A'}</span></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs text-slate-500">
                <div>
                  <span className="font-medium">Model Version:</span> {prediction.model_version}
                </div>
                <div>
                  <span className="font-medium">Timestamp:</span> {new Date(prediction.created_at).toLocaleString()}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Prediction History */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-lg flex items-center justify-center">
            <History className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-800">Prediction History</h3>
            <p className="text-sm text-slate-500">Recent predictions made</p>
          </div>
        </div>

        {history.length === 0 ? (
          <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300">
            <History className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p className="text-slate-500">No predictions yet</p>
            <p className="text-sm text-slate-400 mt-1">Generate a prediction to see history here</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Patient ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Anomaly</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Model</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {history.map((pred) => {
                  const statusConfig = getStatusConfig(pred.predicted_status);
                  return (
                    <tr key={pred.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm text-slate-800">{pred.patient_id}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${statusConfig.bg} ${statusConfig.text}`}>
                          {pred.predicted_status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{pred.is_anomaly === 1 ? 'Yes' : 'No'}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{pred.model_version}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{new Date(pred.created_at).toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default PatientPrediction;
