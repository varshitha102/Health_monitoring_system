import React, { useState, useEffect } from 'react';
import { Phone, Mail, Edit, Trash2, AlertCircle, CheckCircle, Clock, XCircle, ChevronDown, ChevronUp } from 'lucide-react';
import ContactManager from '../components/ContactManager';
import NotificationHistory from '../components/NotificationHistory';
import { contactsAPI, notificationsAPI } from '../services/api';

const EmergencyManagement = () => {
  const [contacts, setContacts] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    sent: 0,
    pending: 0,
    failed: 0
  });
  const [twilioExpanded, setTwilioExpanded] = useState(true);

  useEffect(() => {
    fetchContacts();
    fetchStats();
  }, []);

  const fetchContacts = async () => {
    try {
      const response = await contactsAPI.getAll();
      setContacts(response.data);
    } catch (err) {
      console.error('Failed to fetch contacts:', err);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await notificationsAPI.getAll({ limit: 1000 });
      const notifications = response.data;
      
      setStats({
        total: notifications.length,
        sent: notifications.filter(n => n.delivery_status === 'SENT').length,
        pending: notifications.filter(n => n.delivery_status === 'SENDING' || n.delivery_status === 'CREATING').length,
        failed: notifications.filter(n => n.delivery_status === 'FAILED').length
      });
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-xl flex items-center justify-center">
            <AlertCircle className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Emergency Management</h2>
            <p className="text-slate-500 text-sm">Manage emergency contacts and monitor automated health alert notifications</p>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 mb-1">Total Notifications</p>
              <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
              <Phone className="w-6 h-6 text-slate-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 mb-1">Successful</p>
              <p className="text-3xl font-bold text-green-600">{stats.sent}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 mb-1">Pending</p>
              <p className="text-3xl font-bold text-blue-600">{stats.pending}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 mb-1">Failed</p>
              <p className="text-3xl font-bold text-red-600">{stats.failed}</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
              <XCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Twilio Configuration */}
      <div className="bg-gradient-to-r from-amber-50 to-yellow-50 rounded-2xl border border-amber-200 overflow-hidden">
        <button
          onClick={() => setTwilioExpanded(!twilioExpanded)}
          className="w-full px-6 py-4 flex items-center justify-between hover:bg-amber-100/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center">
              <Phone className="w-5 h-5 text-white" />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-amber-900">Twilio SMS Delivery Setup</h3>
              <p className="text-sm text-amber-700">Configure your Twilio account for SMS notifications</p>
            </div>
          </div>
          {twilioExpanded ? <ChevronUp className="w-5 h-5 text-amber-700" /> : <ChevronDown className="w-5 h-5 text-amber-700" />}
        </button>
        
        {twilioExpanded && (
          <div className="px-6 pb-6">
            <div className="mt-4 bg-white/50 rounded-xl p-4">
              <p className="text-sm text-amber-800 mb-3 font-semibold">
                To receive actual SMS messages, verify your phone number in Twilio:
              </p>
              <ol className="text-sm text-amber-700 space-y-2 list-decimal list-inside">
                <li>Go to <a href="https://console.twilio.com" target="_blank" className="underline hover:text-amber-900 font-medium">console.twilio.com</a></li>
                <li>Navigate to "Phone Numbers" → "Verified Caller IDs"</li>
                <li>Click "Add Verified Caller ID"</li>
                <li>Enter your phone number (e.g., +919110542032033)</li>
                <li>Enter the verification code sent to your phone</li>
                <li>After verification, SMS will be delivered to your number</li>
              </ol>
              <div className="mt-3 p-3 bg-amber-100 rounded-lg">
                <p className="text-xs text-amber-800">
                  <strong>Note:</strong> Twilio trial accounts can only send SMS to verified numbers. Upgrade to remove this restriction.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Contact Manager */}
      <ContactManager />

      {/* Notification History */}
      <NotificationHistory />
    </div>
  );
};

export default EmergencyManagement;
