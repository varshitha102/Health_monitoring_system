import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Contacts API
export const contactsAPI = {
  getAll: () => api.get('/api/contacts/'),
  getById: (id) => api.get(`/api/contacts/${id}`),
  create: (data) => api.post('/api/contacts/', data),
  update: (id, data) => api.put(`/api/contacts/${id}`, data),
  delete: (id) => api.delete(`/api/contacts/${id}`),
};

// Notifications API
export const notificationsAPI = {
  sendAlert: (data) => api.post('/api/notifications/send-alert', data),
  getAll: (params) => api.get('/api/notifications/', { params }),
  getById: (id) => api.get(`/api/notifications/${id}`),
};

// Predictions API
export const predictionsAPI = {
  create: (data) => api.post('/api/predictions/', data),
  getAll: (params) => api.get('/api/predictions/', { params }),
  getById: (id) => api.get(`/api/predictions/${id}`),
  getModelInfo: () => api.get('/api/predictions/model/info'),
};

export default api;
