import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation, Outlet } from 'react-router-dom';
import { Activity, AlertTriangle, HeartPulse, Settings as SettingsIcon, Menu, X, Bell, User, Clock } from 'lucide-react';
import ScenarioMonitoring from './pages/ScenarioMonitoring';
import EmergencyManagement from './pages/EmergencyManagement';
import PatientPrediction from './pages/PatientPrediction';
import Settings from './pages/Settings';

function App() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const navItems = [
    { path: '/', label: 'Scenario Monitoring', icon: Activity },
    { path: '/emergency', label: 'Emergency Management', icon: AlertTriangle },
    { path: '/prediction', label: 'Patient Prediction', icon: HeartPulse },
    { path: '/settings', label: 'Settings', icon: SettingsIcon },
  ];

  const getPageTitle = () => {
    const item = navItems.find(item => item.path === location.pathname);
    return item ? item.label : 'Health Monitoring System';
  };

  // Load patient settings
  const [patientSettings, setPatientSettings] = useState({
    patientName: '',
    patientId: 'P001'
  });

  useEffect(() => {
    const savedSettings = localStorage.getItem('patientSettings');
    if (savedSettings) {
      const settings = JSON.parse(savedSettings);
      setPatientSettings({
        patientName: settings.patientName || '',
        patientId: settings.patientId || 'P001'
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Sidebar */}
      <aside 
        className={`fixed left-0 top-0 h-full bg-gradient-to-b from-[#1F06AC] to-[#0F42C0] text-white transition-all duration-300 ease-in-out z-50 ${
          sidebarOpen ? 'w-64' : 'w-20'
        }`}
      >
        {/* Logo */}
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#E3EF4F] rounded-lg flex items-center justify-center">
              <HeartPulse className="w-6 h-6 text-[#1F06AC]" />
            </div>
            {sidebarOpen && (
              <div>
                <h1 className="font-bold text-lg leading-tight">HEALTH</h1>
                <p className="text-xs text-white/70">MONITORING</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-[#E3EF4F] text-[#1F06AC] shadow-lg'
                    : 'text-white/80 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {sidebarOpen && <span className="font-medium">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Toggle Button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute bottom-6 right-4 w-10 h-10 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
        >
          {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </aside>

      {/* Main Content */}
      <div className={`transition-all duration-300 ease-in-out ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        {/* Topbar */}
        <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-40">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              {/* Breadcrumb */}
              <div>
                <h2 className="text-2xl font-bold text-slate-800">{getPageTitle()}</h2>
                <p className="text-sm text-slate-500 mt-1">
                  Real-time health monitoring and emergency alert system
                </p>
              </div>

              {/* Right Side */}
              <div className="flex items-center gap-6">
                {/* Time */}
                <div className="hidden md:flex items-center gap-2 text-slate-600">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-medium">
                    {currentTime.toLocaleTimeString()}
                  </span>
                </div>

                {/* Notification */}
                <button className="relative p-2 text-slate-600 hover:text-[#1F06AC] hover:bg-slate-100 rounded-lg transition-colors">
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>

                {/* Patient Profile */}
                <div className="flex items-center gap-3 pl-6 border-l border-slate-200">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#1F06AC] to-[#0F42C0] rounded-full flex items-center justify-center text-white font-bold">
                    {patientSettings.patientName ? patientSettings.patientName.charAt(0).toUpperCase() : '?'}
                  </div>
                  <div className="hidden md:block">
                    <p className="font-semibold text-slate-800 text-sm">
                      {patientSettings.patientName || 'Not Configured'}
                    </p>
                    <p className="text-xs text-slate-500">ID: {patientSettings.patientId}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          <Routes>
            <Route path="/" element={<ScenarioMonitoring />} />
            <Route path="/emergency" element={<EmergencyManagement />} />
            <Route path="/prediction" element={<PatientPrediction />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-slate-200 mt-8">
          <div className="px-6 py-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <p className="text-sm text-slate-600">
                Health Monitoring System - Academic Project
              </p>
              <p className="text-xs text-slate-500">
                Isolation Forest Anomaly Detection + Rule-Based Classification + Twilio SMS
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
